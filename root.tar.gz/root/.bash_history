history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
exit
ps aux | grep -E "apt|dpkg|whiptail|debconf" | grep -v grep
kill 38747 38490 38463 16783 1905
echo "grub-pc grub-pc/install_devices multiselect /dev/sda" | debconf-set-selections
DEBIAN_FRONTEND=noninteractive dpkg --configure -a --force-confold
DEBIAN_FRONTEND=noninteractive apt full-upgrade -y -o Dpkg::Options::="--force-confold"
grub-install /dev/sda && update-grub
ssh -p 2222 root@127.0.0.1
ssh -p 2222 root@127.0.0.1
ssh -p 2222 root@127.0.0.1
uptime; cat /etc/debian_version
reboot
hostnamectl set-hostname TPServer
nano /etc/hosts
/etc/hosts
sed -i s/debian/TPServer/g /etc/hosts
cat /etc/hosts
hostname
apt update && apt install -y nano
ip a
cat /etc/network/interfaces
cat /etc/resolv.conf
loadkey us
loadkeys us
sed -i s/75.75.75/8.8.8.8/ /etc/resolv.conf
ping -c 3 deb.debian.org
apt update && apt install -y nano
sed -i /fastly.debian.org/d /etc/apt/sources.list
sed 'i s/cdn2-fastly.deb.debian.org/deb.debian.org/ /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt install -y nano
sed -i s-cdn2-fastly.deb.debian.org/deb.debian.org/ /etcapt/sources.list
sed -i s/cdn2-fastly.deb.debian.org/deb.debian.org/ /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt install -y nano
apt install -y openssh-server
nano /etc/ssh/sshd_config
grep PermitRootLogin /etc/ssh/sshd_config
systemctl restart ssh
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
grep ^PermitRootLogin /etc/ssh/sshd_config
systemctl restart ssh
sed -i 's/^PermitRootLogin .*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
grep ^PermitRootLogin /etc/ssh/sshd_config
sshd -t && systemctl restart ssh && echo SSH-OK
cat > /etc/apt/sources.list <<EOF
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

apt update && apt full-upgrade -y
uname -r; cat /etc/debian_version
ip -br a
cat > /etc/network/interfaces <<EOF
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

auto enp0s3
iface enp0s3 inet static
    address 10.0.2.15
    netmask 255.255.255.0
    gateway 10.0.2.2
EOF

echo nameserver 8.8.8.8 > /etc/resolv.conf
systemctl restart networking
ip a show enp0s3; ip route; ping -c 2 deb.debian.org
lsblk; ls -la /root
apt install -y apache2 php libapache2-mod-php php-mysql mariadb-server
lsblk; ls -la /root
mkdir -p /root/material && tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root/material
ls -laR /root/material
cat /etc/fstab; ls /home
cat /root/material/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
wc -l /root/.ssh/authorized_keys
mysql < /root/material/Material_Adicional_TPVMCA/db.sql
mysql -e "SHOW DATABASES;"
mkdir -p /opt/scripts && nano /opt/scripts/backup_full.sh
cat > /opt/scripts/backup_full.sh <<'EOF'
#!/bin/bash
# backup_full.sh - Comprime un directorio en un .tar.gz con la fecha en el nombre
# Uso: backup_full.sh ORIGEN DESTINO
ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
LOG=/var/log/backup_full.log
# 1. Ayuda
if [ "$1" = "-help" ]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Crea DESTINO/<nombre>_bkp_AAAAMMDD.tar.gz con el contenido de ORIGEN"
    exit 0
fi
# 2. Argumentos
if [ $# -ne 2 ]; then
    echo "Error: faltan argumentos. Usa: $0 -help"
    exit 1
fi
# 3. Validar origen y destino
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen $ORIGEN no existe"
    exit 1
fi
if ! mountpoint -q "$DESTINO"; then
    echo "Error: $DESTINO no esta montado"
    exit 1
fi
# 4. Backup
NOMBRE="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN" 2>>"$LOG"
# 5. Resultado al log
if [ $? -eq 0 ]; then
    echo "$(date) OK: $DESTINO/$NOMBRE" >> "$LOG"
else
    echo "$(date) ERROR al respaldar $ORIGEN" >> "$LOG"
    exit 1
fi
EOF

chmod +x /opt/scripts/backup_full.sh && bash -n /opt/scripts/backup_full.sh && /opt/scripts/backup_full.sh -help
wc -l /opt/scripts/backup_full.sh; tail -n 10 /opt/scripts/backup_full.sh
# 4. Backup
NOMBRE="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN" 2>>"$LOG"
# 5. Resultado al log
if [ $? -eq 0 ]; then     echo "$(date) OK: $DESTINO/$NOMBRE" >> "$LOG"; else     echo "$(date) ERROR al respaldar $ORIGEN" >> "$LOG";     exit 1; fi
ssh -p 2222 root@127.0.0.1
lsblk; crontab -l
(crontab -l 2>/dev/null; echo "0 0 * * * /opt/scripts/backup_full.sh /var/log /backup_dir"; echo "0 23 * * 1,3,5 /opt/scripts/backup_full.sh /www_dir /backup_dir") | crontab -
crontab -l | tail -n 3
poweroff
lsblk
printf "n\np\n1\n\n+3G\nn\np\n2\n\n+6G\nw\n" | fdisk /dev/sdc
lsblk /dev/sdc
mkfs.ext4 -F /dev/sdc1 && mkfs.ext4 -F /dev/sdc2
mkdir -p /www_dir /backup_dir
echo "/dev/sdc1 /www_dir ext4 defaults 0 2" >> /etc/fstab && echo "/dev/sdc2 /backup_dir ext4 defaults 0 2" >> /etc/fstab
systemctl daemon-reload && mount -a && df -h | grep -E "www_dir|backup_dir"
cat /proc/partitions > /opt/particion && cat /opt/particion
cp /root/material/Material_Adicional_TPVMCA/index.php /root/material/Material_Adicional_TPVMCA/logo.png /www_dir/ && chown -R www-data:www-data /www_dir && ls -l /www_dir
sed -i 's#DocumentRoot /var/www/html#DocumentRoot /www_dir#' /etc/apache2/sites-available/000-default.conf && grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/apache2.conf <<EOF

<Directory /www_dir/>
    Options Indexes FollowSymLinks
    AllowOverride None
    Require all granted
</Directory>
EOF

apachectl configtest && systemctl restart apache2 && echo APACHE-OK
grep -n -i -E "mysqli|new PDO|host|user|pass|dbname|localhost" /www_dir/index.php
mysql -e "CREATE USER IF NOT EXISTS 'lcars'@'localhost' IDENTIFIED BY 'NCC1701D'; GRANT ALL PRIVILEGES ON ingenieria.* TO 'lcars'@'localhost'; FLUSH PRIVILEGES;"
mysql -u lcars -pNCC1701D -e "USE ingenieria; SHOW TABLES;"
http://127.0.0.1:8080
/opt/scripts/backup_full.sh /var/log /backup_dir && /opt/scripts/backup_full.sh /www_dir /backup_dir && ls -lh /backup_dir && tail -n 2 /var/log/backup_full.log
cat > /etc/network/interfaces <<EOF
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

auto enp0s3
iface enp0s3 inet static
    address 10.0.0.200
    netmask 255.255.255.0
    gateway 10.0.0.1
EOF

cat /etc/network/interfaces && echo nameserver 8.8.8.8 > /etc/resolv.conf && poweroff
