#!/bin/bash
# backup_full.sh - Comprime un directorio en un .tar.gz con la fecha en el nombre
# Uso: backup_full.sh ORIGEN DESTINO
ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
LOG=/var/log/backup_full.log
# 1. Ayuda
if [ "$1" = "-help" ]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Crea DESTINO/<nombre>_bkp_AAAAMMDD.tar.gz con el contenido de ORIGEN"
    exit 0
fi
# 2. Argumentos
if [ $# -ne 2 ]; then
    echo "Error: faltan argumentos. Usa: $0 -help"
    exit 1
fi
# 3. Validar origen y destino
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen $ORIGEN no existe"
    exit 1
fi
if ! mountpoint -q "$DESTINO"; then
    echo "Error: $DESTINO no esta montado"
    exit 1
fi
# 4. Backup
NOMBRE="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN" 2>>"$LOG"
# 5. Resultado al log
if [ $? -eq 0 ]; then
    echo "$(date) OK: $DESTINO/$NOMBRE" >> "$LOG"
else
    echo "$(date) ERROR al respaldar $ORIGEN" >> "$LOG"
    exit 1
fi
